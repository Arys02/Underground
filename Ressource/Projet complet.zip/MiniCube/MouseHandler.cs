﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

namespace Underground
{
    public class MouseHandler
    {
        public bool MouseRight { get; private set; }

        private bool mouseLeft;
        public bool MouseLeft
        {
            get
            {
                //Only one left is set if the user holds..
                if (mouseLeft)
                {
                    mouseLeft = false;
                    return true;
                }
                return mouseLeft;
            }
        }

        public void MouseDown(Object sender, MouseEventArgs earg)
        {
            switch (earg.Button)
            {
                case MouseButtons.Left:
                    mouseLeft = true;
                    return;
                case MouseButtons.Right:
                    MouseRight = true;
                    return;
            }
        }

        public void MouseUp(Object sender, MouseEventArgs earg)
        {
            switch (earg.Button)
            {
                case MouseButtons.Left:
                    mouseLeft = false;
                    return;
                case MouseButtons.Right:
                    MouseRight = true;
                    return;
            }
        }
    }
}
